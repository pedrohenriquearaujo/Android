package com.example.pedro.estacionamentoversion1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    int estado = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView list = findViewById(R.id.vagas);

        ArrayList<String> vagas = preencherVagas();

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, vagas);
        list.setAdapter(arrayAdapter);

        final Button b1 = findViewById(R.id.button1);   b1.setBackgroundResource(R.color.Verde);
        final Button b2 = findViewById(R.id.button2);    b2.setBackgroundResource(R.color.Verde);
        final Button b3 = findViewById(R.id.button3);    b3.setBackgroundResource(R.color.Verde);
        final Button b4 = findViewById(R.id.button4);    b4.setBackgroundResource(R.color.Verde);
        final Button b5 = findViewById(R.id.button5);    b5.setBackgroundResource(R.color.Verde);

        final Button b7 = findViewById(R.id.button7);      b7.setBackgroundResource(R.color.Verde);
        final Button b8 = findViewById(R.id.button8);  b8.setBackgroundResource(R.color.Verde);
        final Button b9 = findViewById(R.id.button9);  b9.setBackgroundResource(R.color.Verde);
        final Button b11 = findViewById(R.id.button11);  b11.setBackgroundResource(R.color.Verde);
        final Button b12 = findViewById(R.id.button12);  b12.setBackgroundResource(R.color.Verde);

        final ImageView img1 = findViewById(R.id.img1);
        final ImageView img2 = findViewById(R.id.img2);
        final ImageView img3 = findViewById(R.id.img3);
        final ImageView img4 = findViewById(R.id.img4);
        final ImageView img5 = findViewById(R.id.img5);
        final ImageView img6 = findViewById(R.id.img6);

        final ImageView img7 = findViewById(R.id.img7);

        final ImageView img8 = findViewById(R.id.img8);


        list.setOnItemClickListener( new AdapterView.OnItemClickListener(){

            public void onItemClick(AdapterView<?> parent, View view, int position, long id){

                if(position == 0)
                    img1.setVisibility(View.VISIBLE);
                else if(position == 1)
                    img2.setVisibility(View.VISIBLE);
                else if(position == 2)
                    img3.setVisibility(View.VISIBLE);
                else if(position == 3)
                    img4.setVisibility(View.VISIBLE);
                else if(position == 4)
                    img5.setVisibility(View.VISIBLE);
                else if(position == 5)
                    img6.setVisibility(View.VISIBLE);
                else if(position == 6)
                    img7.setVisibility(View.VISIBLE);
                else
                    img8.setVisibility(View.VISIBLE);

            }
        });



        b1.setOnClickListener( new Button.OnClickListener()
                                  {
                                      public void onClick(View v){

                                          if(estado == 0){
                                              b1.setBackgroundResource(R.color.Cinza);

                                          estado = 1;
                                          }else{
                                              b1.setBackgroundResource(R.color.Verde);
                                              estado = 0;

                                          }
                                      }
                                  }
        );
        b2.setOnClickListener( new Button.OnClickListener()
                                           {
                                               public void onClick(View v){

                                                   if(estado == 0){
                                                       b2.setBackgroundResource(R.color.Cinza);
                                                       estado = 1;
                                                   }else{
                                                       b2.setBackgroundResource(R.color.Verde);
                                                       estado = 0;
                                                   }
                                               }
                                           }
        );
        b3.setOnClickListener( new Button.OnClickListener()
                               {
                                   public void onClick(View v){

                                       if(estado == 0){
                                           b3.setBackgroundResource(R.color.Cinza);
                                           estado = 1;
                                       }else{
                                           b3.setBackgroundResource(R.color.Verde);
                                           estado = 0;
                                       }
                                   }
                               }
        );
        b4.setOnClickListener( new Button.OnClickListener()
                               {
                                   public void onClick(View v){

                                       if(estado == 0){
                                           b4.setBackgroundResource(R.color.Cinza);
                                           estado = 1;
                                       }else{
                                           b4.setBackgroundResource(R.color.Verde);
                                           estado = 0;
                                       }
                                   }
                               }
        );
        b5.setOnClickListener( new Button.OnClickListener()
                               {
                                   public void onClick(View v){

                                       if(estado == 0){
                                           b5.setBackgroundResource(R.color.Cinza);
                                           estado = 1;
                                       }else{
                                           b5.setBackgroundResource(R.color.Verde);
                                           estado = 0;
                                       }
                                   }
                               }
        );

        b7.setOnClickListener( new Button.OnClickListener()
                               {
                                   public void onClick(View v){

                                       if(estado == 0){
                                           b7.setBackgroundResource(R.color.Cinza);
                                           estado = 1;
                                       }else{
                                           b7.setBackgroundResource(R.color.Verde);
                                           estado = 0;
                                       }
                                   }
                               }
        );
        b8.setOnClickListener( new Button.OnClickListener()
                               {
                                   public void onClick(View v){

                                       if(estado == 0){
                                           b8.setBackgroundResource(R.color.Cinza);
                                           estado = 1;
                                       }else{
                                           b8.setBackgroundResource(R.color.Verde);
                                           estado = 0;
                                       }
                                   }
                               }
        );
        b9.setOnClickListener( new Button.OnClickListener()
                               {
                                   public void onClick(View v){

                                       if(estado == 0){
                                           b9.setBackgroundResource(R.color.Cinza);
                                           estado = 1;
                                       }else{
                                           b9.setBackgroundResource(R.color.Verde);
                                           estado = 0;
                                       }
                                   }
                               }
        );
        b11.setOnClickListener( new Button.OnClickListener()
                               {
                                   public void onClick(View v){

                                       if(estado == 0){
                                           b11.setBackgroundResource(R.color.Cinza);
                                           estado = 1;
                                       }else{
                                           b11.setBackgroundResource(R.color.Verde);
                                           estado = 0;
                                       }
                                   }
                               }
        );
        b12.setOnClickListener( new Button.OnClickListener()
                               {
                                   public void onClick(View v){

                                       if(estado == 0){
                                           b12.setBackgroundResource(R.color.Cinza);
                                           estado = 1;
                                       }else{
                                           b12.setBackgroundResource(R.color.Verde);
                                           estado = 0;
                                       }
                                   }
                               }
        );


    }

    private ArrayList<String> preencherVagas (){

        ArrayList<String> vagas = new ArrayList<String>();
        vagas.add("1");
        vagas.add("2");
        vagas.add("3");
        vagas.add("4");
        vagas.add("5");
        vagas.add("6");
        vagas.add("7");
        vagas.add("8");

        return vagas;
    }



}
